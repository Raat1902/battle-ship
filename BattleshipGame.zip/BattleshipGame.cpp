#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace std;

const int SIZE = 5;
const int NUM_SHIPS = 3;

struct Ship {
    int row, col;
};

void printBoard(const vector<vector<char>>& board) {
    cout << "  ";
    for (int i = 0; i < SIZE; ++i) cout << i << " ";
    cout << endl;
    for (int i = 0; i < SIZE; ++i) {
        cout << i << " ";
        for (int j = 0; j < SIZE; ++j) {
            cout << board[i][j] << " ";
        }
        cout << endl;
    }
}

bool isHit(const vector<Ship>& ships, int row, int col) {
    for (const Ship& s : ships) {
        if (s.row == row && s.col == col) return true;
    }
    return false;
}

int main() {
    srand(time(0));

    vector<vector<char>> board(SIZE, vector<char>(SIZE, '.'));
    vector<Ship> ships;

    // Randomly place ships
    while (ships.size() < NUM_SHIPS) {
        int r = rand() % SIZE;
        int c = rand() % SIZE;
        bool overlap = false;
        for (const Ship& s : ships) {
            if (s.row == r && s.col == c) {
                overlap = true;
                break;
            }
        }
        if (!overlap) ships.push_back({r, c});
    }

    int turns = 10;
    int hits = 0;

    cout << "=== Battleship Game ===\n";
    cout << "Board size: " << SIZE << "x" << SIZE << ", Ships: " << NUM_SHIPS << ", Turns: " << turns << "\n";

    while (turns > 0 && hits < NUM_SHIPS) {
        printBoard(board);
        int row, col;
        cout << "Enter row and column to fire (e.g., 2 3): ";
        cin >> row >> col;

        if (row < 0 || row >= SIZE || col < 0 || col >= SIZE) {
            cout << "Out of bounds. Try again.\n";
            continue;
        }

        if (board[row][col] == 'X' || board[row][col] == 'O') {
            cout << "Already fired there. Try again.\n";
            continue;
        }

        if (isHit(ships, row, col)) {
            board[row][col] = 'X';
            hits++;
            cout << "Hit!\n";
        } else {
            board[row][col] = 'O';
            cout << "Miss.\n";
        }

        turns--;
    }

    printBoard(board);
    if (hits == NUM_SHIPS) {
        cout << "You sunk all ships! You win!\n";
    } else {
        cout << "Game over. You missed too many times.\n";
        cout << "Ship locations were:\n";
        for (const Ship& s : ships) {
            cout << "- (" << s.row << ", " << s.col << ")\n";
        }
    }

    return 0;
}